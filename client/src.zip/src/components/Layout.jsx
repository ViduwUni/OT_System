import FloatingNavbar from "./FloatingNavBar";
import SideBar from "./SideBar";

export default function Layout({ children }) {
  return (
    <div className="relative">
      {/* Sidebar - fixed */}
      <div className="fixed top-0 left-0 h-screen w-24 border-solid flex flex-col bg-primary text-text shadow-lg z-50">
        <SideBar />
      </div>

      {/* Top Navbar - fixed */}
      <div className="fixed top-4 left-24 right-40 h-16 bg-white shadow-md z-40 flex items-center justify-between px-4 rounded-md">
        <FloatingNavbar />
      </div>

      {/* Main Content */}
      <main className="ml-24 mr-40 mt-32 px-4 bg-green-300 shadow-md z-10 rounded-md min-h-screen">
        {children}
      </main>
    </div>
  );
}
